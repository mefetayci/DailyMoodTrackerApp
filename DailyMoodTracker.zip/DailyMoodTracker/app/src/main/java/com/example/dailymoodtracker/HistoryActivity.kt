package com.example.dailymoodtracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dailymoodtracker.adapter.MoodAdapter
import com.example.dailymoodtracker.model.MoodItem
import okhttp3.*
import org.json.JSONArray
import java.io.File
import java.io.IOException

class HistoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnExport: Button
    private val moodList = ArrayList<MoodItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        recyclerView = findViewById(R.id.recyclerViewHistory)
        recyclerView.layoutManager = LinearLayoutManager(this)

        btnExport = findViewById(R.id.btnExport)
        btnExport.setOnClickListener {
            exportMoodsAsTxt()
        }

        getMoodHistory()
    }

    private fun getMoodHistory() {
        val request = Request.Builder()
            .url("http://10.0.2.2:5000/get_moods")
            .build()

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@HistoryActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.let { responseBody ->
                    val jsonArray = JSONArray(responseBody.string())
                    moodList.clear()

                    for (i in 0 until jsonArray.length()) {
                        val obj = jsonArray.getJSONObject(i)
                        val item = MoodItem(
                            id = obj.getInt("id"),
                            mood = obj.getString("mood"),
                            note = obj.getString("note"),
                            timestamp = obj.getString("timestamp")
                        )
                        moodList.add(item)
                    }

                    runOnUiThread {
                        recyclerView.adapter = MoodAdapter(moodList)
                    }
                }
            }
        })
    }

    private fun exportMoodsAsTxt() {
        if (moodList.isEmpty()) {
            Toast.makeText(this, "No moods to export", Toast.LENGTH_SHORT).show()
            return
        }

        val exportText = StringBuilder()
        moodList.forEach {
            exportText.append("Mood: ${it.mood}\nNote: ${it.note}\nDate: ${it.timestamp}\n\n")
        }

        try {
            val fileName = "moods_export.txt"
            val file = File(getExternalFilesDir(null), fileName)
            file.writeText(exportText.toString())

            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "My Mood Data")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            startActivity(Intent.createChooser(shareIntent, "Share mood file via:"))

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Export failed", Toast.LENGTH_SHORT).show()
        }
    }
}
