package com.example.dailymoodtracker

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.Description
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import okhttp3.*
import org.json.JSONArray
import java.io.IOException

class MoodSummaryActivity : AppCompatActivity() {

    private lateinit var barChart: BarChart
    private val moodCounts = mutableMapOf<String, Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_summary)

        barChart = findViewById(R.id.barChartMood)
        getMoodData()
    }

    private fun getMoodData() {
        val request = Request.Builder()
            .url("http://10.0.2.2:5000/get_moods")
            .build()

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                val jsonArray = JSONArray(response.body?.string())
                moodCounts.clear()

                for (i in 0 until jsonArray.length()) {
                    val mood = jsonArray.getJSONObject(i).getString("mood")
                    moodCounts[mood] = moodCounts.getOrDefault(mood, 0) + 1
                }

                runOnUiThread {
                    setupBarChart()
                }
            }
        })
    }

    private fun setupBarChart() {
        val entries = ArrayList<BarEntry>()
        val labels = ArrayList<String>()
        var index = 0f

        moodCounts.forEach { (mood, count) ->
            entries.add(BarEntry(index, count.toFloat()))
            labels.add(mood)
            index++
        }

        val dataSet = BarDataSet(entries, "Mood Summary")
        dataSet.color = Color.parseColor("#6C63FF")
        dataSet.valueTextSize = 16f

        val data = BarData(dataSet)
        barChart.data = data
        barChart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        barChart.xAxis.granularity = 1f
        barChart.xAxis.isGranularityEnabled = true
        barChart.axisLeft.axisMinimum = 0f
        barChart.axisRight.isEnabled = false
        barChart.description = Description().apply { text = "" }
        barChart.invalidate()
    }
}
