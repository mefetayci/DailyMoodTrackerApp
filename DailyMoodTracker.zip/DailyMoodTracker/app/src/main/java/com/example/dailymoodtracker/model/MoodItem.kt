package com.example.dailymoodtracker.model

data class MoodItem(
    val id: Int,
    val mood: String,
    val note: String,
    val timestamp: String
)
