package com.example.dailymoodtracker

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.io.IOException

class MoodEntryActivity : AppCompatActivity() {

    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mood_entry)

        val radioGroupMood = findViewById<RadioGroup>(R.id.radioGroupMood)
        val etNote = findViewById<EditText>(R.id.etNote)
        val btnSaveMood = findViewById<Button>(R.id.btnSaveMood)

        btnSaveMood.setOnClickListener {
            val selectedId = radioGroupMood.checkedRadioButtonId
            if (selectedId == -1) {
                Toast.makeText(this, "Please select a mood", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selectedRadio = findViewById<RadioButton>(selectedId)
            val mood = selectedRadio.text.toString()
            val note = etNote.text.toString()

            sendMoodToServer(mood, note)
        }
    }

    private fun sendMoodToServer(mood: String, note: String) {
        val formBody = FormBody.Builder()
            .add("mood", mood)
            .add("note", note)
            .build()

        val request = Request.Builder()
            .url("http://10.0.2.2:5000/add_mood") // XAMPP yerine Flask çalışıyorsa 10.0.2.2
            .post(formBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MoodEntryActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    if (response.isSuccessful) {
                        Toast.makeText(this@MoodEntryActivity, "Mood saved!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@MoodEntryActivity, "Failed to save mood", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }
}