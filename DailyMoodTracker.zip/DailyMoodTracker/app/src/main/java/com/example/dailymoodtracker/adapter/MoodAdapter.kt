package com.example.dailymoodtracker.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.dailymoodtracker.R
import com.example.dailymoodtracker.model.MoodItem

class MoodAdapter(private val moodList: List<MoodItem>) :
    RecyclerView.Adapter<MoodAdapter.MoodViewHolder>() {

    class MoodViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtMood: TextView = view.findViewById(R.id.txtMood)
        val txtNote: TextView = view.findViewById(R.id.txtNote)
        val txtDate: TextView = view.findViewById(R.id.txtDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MoodViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_mood, parent, false)
        return MoodViewHolder(view)
    }

    override fun onBindViewHolder(holder: MoodViewHolder, position: Int) {
        val mood = moodList[position]
        holder.txtMood.text = mood.mood
        holder.txtNote.text = mood.note
        holder.txtDate.text = mood.timestamp
    }

    override fun getItemCount() = moodList.size
}
