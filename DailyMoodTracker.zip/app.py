from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector

app = Flask(__name__)
CORS(app)

# Veritabanı bağlantısı
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",          # şifre koymadıysan root
        password="",          # varsa buraya ekle
        database="moodtracker"
    )

# Veri ekleme
@app.route('/add_mood', methods=['POST'])
def add_mood():
    mood = request.form.get('mood')
    note = request.form.get('note')

    db = connect_db()
    cursor = db.cursor()
    sql = "INSERT INTO moods (mood, note) VALUES (%s, %s)"
    cursor.execute(sql, (mood, note))
    db.commit()

    cursor.close()
    db.close()
    return jsonify({"message": "Mood added successfully"}), 200

# Mood geçmişi
@app.route('/get_moods', methods=['GET'])
def get_moods():
    db = connect_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM moods ORDER BY timestamp DESC")
    rows = cursor.fetchall()
    cursor.close()
    db.close()
    return jsonify(rows)

if __name__ == '__main__':
    app.run(debug=True)
